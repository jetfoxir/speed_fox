<?php
/*
 * Plugin Name:           سوپر راکت (بهینه ساز سایت و افزودنی راکت)
 * Plugin URI:          https://jetfox.ir/
 * download_url: https://jetfox.ir/update/jetfox.zip
 * Description:         فشرده سازی سایت و افزایش سرعت 
 * Version:             1.0.0
 * Requires at least:   6.0.1
 * Requires PHP:        7.2
 * Author:              رضا غلامیان 
 * Author URI:          https://jetfox.ir/
 * License:             GPL
 * License URI:         https://jetfox.ir/
 * Text Domain:         jetfox
 * Domain Path:         /languages
 */


define('WP_JTF_DIR', plugin_dir_path(__FILE__));
define('WP_JTF_URL', plugin_dir_url(__FILE__));
define('WP_JTF_INC', WP_JTF_DIR . '/inc/');
define('WP_JTF_BASE',WP_JTF_DIR . '/fun/');
//define('WP_JTF_TPL', WP_JTF_DIR . '/tpl/');

include WP_JTF_INC . 'menu.php';
include WP_JTF_BASE . 'minify.php';

////////////////////////////////////////////////////////////////////////////////////////////////style///////////////////////////////////////////////////////////////////////////////////
function style () {
	$css_file = ( is_admin() ? 'font-dashboard.css' : 'font.css' );
	wp_enqueue_style( 'font_speed', plugin_dir_url( __FILE__ ) . "asset/css/" . $css_file );
}
add_action( 'admin_enqueue_scripts', 'style' );
//add_action( 'wp_enqueue_scripts', 'style' );
add_action( 'login_enqueue_scripts', 'style' );


function menu () {
	$css_file = ( is_admin() ? 'style.css' : 'style.css' );
	wp_enqueue_style( 'font_menu', plugin_dir_url( __FILE__ ) . "asset/css/" . $css_file );
}
add_action( 'admin_enqueue_scripts', 'menu' );
//add_action( 'wp_enqueue_scripts', 'style' );
//add_action( 'login_enqueue_scripts', 'style' );
////////////////////////////////////////////////////////////////////////////////////////////////style///////////////////////////////////////////////////////////////////////////////////




