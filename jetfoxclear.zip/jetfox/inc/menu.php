<?php
add_action('admin_menu','my_plugin_menu');

function my_plugin_menu(){
 add_menu_page(
           "بهینه سازی",
           "سوپر راکت",
           "manage_options",
           "jetfox", //slug
           "myplugin_callback",
           'dashicons-html',
           2

           );
}


function myplugin_callback(){

	include WP_JTF_INC . 'admin.php';

      
   }
