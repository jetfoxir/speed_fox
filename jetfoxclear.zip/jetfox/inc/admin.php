<?php
include WP_JTF_BASE . 'fun.php';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>تنظیمات افزونه</title>
</head>
<body>

<h1 class = hi> بهینه سازی و افزایش سرعت سایت</h1>
</br>
<h2 class = wel>خوش آمدید.</h2>
<div class="box">
<img class = reza src="../wp-content/plugins/jetfox/asset/images/front_splash.jpg" width="150px" height="150px" alt="" /> <h4 class = ver >ورژن :1.0.0</h4>
<h2 class =text3>پلاگین با موفقیت فعال و تنظیم شد.</h2> 
<h2 class =text2>برای کاهش و رفع خطای های انسانی و جلوگیری از خرابی یا به هم ریختگی ظاهر سایت شما تمام موارد یا تنظیمات با توجه به سایت شما تنظیم میشود.</h2>
<h2 class =text>تمام تنظیمات به صورت خودکار بر اساس وبسایت شما تنظیم شدند.</h2>
</br></br></br>
<!--</br></br></br></br></br></br>-->
<hr>
<h3 class =text4> | موارد و پیکربندی تکمیلی |</h3>
</br>
    <h2 class= css>کد های css فشرده شدند &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; تمام کامنت ها پاک شدند.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;تمام کد های js منسوخ شده حذف شدند.</h2>

</h2>
</br>
</br>
    <h2 class = css>کد های css بهینه شدند.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;تمام کد های html مرتب شدند&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;تمام کد های js فشرده شدند.</h2>
</br>
</br>
    <h2 class = css> کد های css مرتب شدند&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;تمام کد های html فشرده شدند.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;تمام کد های js مرتب شدند.</h2>
    <!--main-->

   
   
    <h2></h2>
    <h2></h2>
    </br></br></br>

</div>
</body>
</html>
